﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 09-01-2021
* CSC 253
* Tracey Pinckney
* This program will display the speed of a car when it accelerates and decelerates
*/
namespace WinFormsUI
{
    //Create a named car
    class Car
    {
        //backing fields
        private int _carYear;
        private string _carMake;
        private int _carSpeed;

        //parameterized constructor will accept and pass the year, make, and model arguments
        public Car(int year, string make, string model)
        {
            CarYear = year;
            CarMake = make;
            CarModel = model;
            CarSpeed = 0;
        }

        

        //This normal property will get the Year and set a value
        public int CarYear 
        {
            get
            {
                return _carYear;
            }
            set
            {
                _carYear = value;
            }
        }
            
        

        //This will get the Make and set a value
        public string CarMake 
        {
            get
            {
                return _carMake;
            }
            set
            {
                _carMake = value;
            }
        }
        

        //This will get the Model and set a value
        
        

        //This will get the Speed and set a value
        public int CarSpeed 
        {
            get
            {
                return _carSpeed;
            }
            set
            {
                _carSpeed = value;
            }
        }

        public string CarModel { get; set; }

        //This will increase the speed

        public void Accelerate(int newSpeed)
        {
            _carSpeed += 5;
        }

       

        //This will decrease the speed
        public void Brake(int newSpeed)
        {
            _carSpeed -= 5;

        }

    }

}
