﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 09-01-2021
* CSC 253
* Tracey Pinckney
* This program will display the speed of a car when it accelerates and decelerates.
*/
namespace WinFormsUI
{

    public partial class Form1 : Form
    {
        //This is the object that will pull data from the Car class
        Car mycar = new Car(2018, "Ford", "Escape");
        public Form1()
        {
         

            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Display the data from the object and Car class
            yearLabel.Text = mycar.CarYear.ToString("");
            makeLabel.Text = mycar.CarMake;
            modelLabel.Text = mycar.CarModel;
            currentSpeedLabel.Text = mycar.CarSpeed.ToString();
        }

        //This button will increase the speed by 5
        private void accelButton_Click(object sender, EventArgs e)
        {
            
            //The if else statment will display the new speed when the accelerate button is clicked
            //The speed will increase when the accelerate button is clicked.
            int newSpeed;
            if (int.TryParse(currentSpeedLabel.Text, out newSpeed))
            {
                mycar.Accelerate(newSpeed);

                newSpeedLabel.Text = mycar.CarSpeed.ToString();


            }

        }
        //This button will decrease the speed by 5
        private void brakeButton_Click(object sender, EventArgs e)
        {
            //The if-else statement will display the new speed when the brakes button is clicked.
            //The speed will reduce when the brakes button is clicked.
            int newSpeed;
            if (int.TryParse(currentSpeedLabel.Text, out newSpeed))
            {
                mycar.Brake(newSpeed);

                newSpeedLabel.Text = mycar.CarSpeed.ToString();
            }
        }

        //This button will clear the text boxes and lables
        private void clearButton_Click(object sender, EventArgs e)
        {
            

            yearLabel.Text = "";
            makeLabel.Text = "";
            modelLabel.Text = "";
            newSpeedLabel.Text = "";
            currentSpeedLabel.Text = "";

          
        }

        //This will close the form
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}