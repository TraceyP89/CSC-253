﻿
namespace WinFormsUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.readRandomNumTotalButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.outputlistBox = new System.Windows.Forms.ListBox();
            this.userAmountTextBox = new System.Windows.Forms.TextBox();
            this.writeRanNumButton = new System.Windows.Forms.Button();
            this.displayTotalLabel = new System.Windows.Forms.Label();
            this.displayNumOfRanNumLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // readRandomNumTotalButton
            // 
            this.readRandomNumTotalButton.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.readRandomNumTotalButton.Location = new System.Drawing.Point(118, 126);
            this.readRandomNumTotalButton.Name = "readRandomNumTotalButton";
            this.readRandomNumTotalButton.Size = new System.Drawing.Size(75, 60);
            this.readRandomNumTotalButton.TabIndex = 0;
            this.readRandomNumTotalButton.Text = "Read Random Number and Total";
            this.readRandomNumTotalButton.UseVisualStyleBackColor = true;
            this.readRandomNumTotalButton.Click += new System.EventHandler(this.readRandomNumTotalButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(199, 126);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 60);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.Location = new System.Drawing.Point(280, 126);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 60);
            this.clearButton.TabIndex = 2;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(97, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(213, 34);
            this.label1.TabIndex = 3;
            this.label1.Text = "Enter how many random nubmer, from 1 to 100, you want to see:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputlistBox
            // 
            this.outputlistBox.FormattingEnabled = true;
            this.outputlistBox.Location = new System.Drawing.Point(37, 213);
            this.outputlistBox.Name = "outputlistBox";
            this.outputlistBox.Size = new System.Drawing.Size(194, 186);
            this.outputlistBox.TabIndex = 5;
            // 
            // userAmountTextBox
            // 
            this.userAmountTextBox.Location = new System.Drawing.Point(116, 87);
            this.userAmountTextBox.Name = "userAmountTextBox";
            this.userAmountTextBox.Size = new System.Drawing.Size(168, 20);
            this.userAmountTextBox.TabIndex = 4;
            // 
            // writeRanNumButton
            // 
            this.writeRanNumButton.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.writeRanNumButton.Location = new System.Drawing.Point(37, 126);
            this.writeRanNumButton.Name = "writeRanNumButton";
            this.writeRanNumButton.Size = new System.Drawing.Size(75, 60);
            this.writeRanNumButton.TabIndex = 6;
            this.writeRanNumButton.Text = "Write Random Number";
            this.writeRanNumButton.UseVisualStyleBackColor = true;
            this.writeRanNumButton.Click += new System.EventHandler(this.writeRanNumButton_Click);
            // 
            // displayTotalLabel
            // 
            this.displayTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayTotalLabel.Location = new System.Drawing.Point(237, 233);
            this.displayTotalLabel.Name = "displayTotalLabel";
            this.displayTotalLabel.Size = new System.Drawing.Size(201, 23);
            this.displayTotalLabel.TabIndex = 7;
            // 
            // displayNumOfRanNumLabel
            // 
            this.displayNumOfRanNumLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayNumOfRanNumLabel.Location = new System.Drawing.Point(237, 302);
            this.displayNumOfRanNumLabel.Name = "displayNumOfRanNumLabel";
            this.displayNumOfRanNumLabel.Size = new System.Drawing.Size(201, 23);
            this.displayNumOfRanNumLabel.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(237, 213);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(187, 14);
            this.label2.TabIndex = 9;
            this.label2.Text = "The total of the numbers listed:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(237, 277);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(200, 14);
            this.label3.TabIndex = 10;
            this.label3.Text = "The number of random numbers:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(477, 405);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.displayNumOfRanNumLabel);
            this.Controls.Add(this.displayTotalLabel);
            this.Controls.Add(this.writeRanNumButton);
            this.Controls.Add(this.outputlistBox);
            this.Controls.Add(this.userAmountTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.readRandomNumTotalButton);
            this.Name = "Form1";
            this.Text = "Random Number File Reader";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button readRandomNumTotalButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox outputlistBox;
        private System.Windows.Forms.TextBox userAmountTextBox;
        private System.Windows.Forms.Button writeRanNumButton;
        private System.Windows.Forms.Label displayTotalLabel;
        private System.Windows.Forms.Label displayNumOfRanNumLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

