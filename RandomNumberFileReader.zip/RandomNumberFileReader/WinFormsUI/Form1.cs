﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using RandomNumberTotalLibrary;
/**
* 09-18-2021
* CSC 253
* Tracey Pinckney
* This program will write an read a file of random numbers
*/
namespace WinFormsUI
{
    public partial class Form1 : Form
    {
        //Object to connect the class and form
        RandomNumberTotal myRandomNum = new RandomNumberTotal(0);
        public Form1()
        {
            InitializeComponent();
        }

        private void writeRanNumButton_Click(object sender, EventArgs e)
        {
            //The try-catch will stop the system from crashing.
            //Instead an error message will appear.
            try
            {
                //created variable outputFile 
                //OutputFile will create a text document called Random Numbers
                StreamWriter outputFile;
                outputFile = File.CreateText("Random Numbers.txt");

                //The if statement will accept a number that user inputs in the text
                //The number entered is how many lines of number they want
                int userAmount;
                if (int.TryParse(userAmountTextBox.Text, out userAmount))
                {

                    // this object will select random number when called
                    Random Rand = new Random();

                    //When the user inputs a number the Random Number will get the data
                    myRandomNum.RandomNumbers = userAmount;
                    userAmount = int.Parse(userAmountTextBox.Text);


                    //This for loop will display number from 1 to 100
                    for (int number = 1; number <= userAmount; number++)
                    {
                        //This variable will display random number from 1 to 100
                        int generatorNum = Rand.Next(1, 100);
                        //This will display the random numbers
                        outputFile.WriteLine(generatorNum);

                    }
                    outputFile.Close();
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // variables
        int total;

        //This button will display what the list of number after the Write button has been clicked
        private void readRandomNumTotalButton_Click(object sender, EventArgs e)
        {
            int randomNums;
            
            //The try-catch will stop the system from crashing.
            //Instead an error message will appear.
            try
            {
                //OutputFile will create a text document called Random Numbers

                //Variable 
                StreamReader inputFile;

                //Will open the Random Numbers file
                inputFile = File.OpenText("Random Numbers.txt");



                
                //This loop will display the random numbers from the file
                while (!inputFile.EndOfStream)
                {
                    randomNums = int.Parse(inputFile.ReadLine());
                    outputlistBox.Items.Add(randomNums);
                    total += randomNums;
                }

                inputFile.Close();

                //Displays the total of the random numbers displayed
                displayTotalLabel.Text = total.ToString();

                //Shows the number of the numbers displayed
                int NumOfRanNum;
                NumOfRanNum = outputlistBox.Items.Count;
                displayNumOfRanNumLabel.Text = NumOfRanNum.ToString();
                    
            }
            //If there is an error a message box will appear with an error message
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear the labels, textbox, and listbox
            userAmountTextBox.Text = "";
            outputlistBox.Items.Clear();
            displayNumOfRanNumLabel.Text = "";
            displayTotalLabel.Text = "";

        }

        
        
    }
}
