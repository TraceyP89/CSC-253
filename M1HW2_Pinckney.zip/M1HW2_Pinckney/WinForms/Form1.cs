﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 08-22-2021
* CSC 253
* Tracey Pinckney
* This program will calculate an object's kinetic energy.
*/
namespace WinForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //This method will return the kinetic energy of an object. 
        private double kineticEnergy(double mass, double velocity)
        {
            return 1.0 / 2.0 * mass * velocity * velocity;
        }

        private void kineticEnergyButton_Click(object sender, EventArgs e)
        {   //Declare variables for the mass, velocity, and energy.
            double mass;
            double velocity;
            double energy;

            //This if statement will get the mass that is entered
            //in the objectMassTextBox.
            if(double.TryParse(objectsMassTextBox.Text, out mass))
            {   //This if statement will get the velocity that is entered
                //in the objectVelocityTextBox.
                if(double.TryParse(objectVelocityTextBox.Text, out velocity))
                {
                    //The method assigned to this variable will jump to the
                    //kineticEnergy method to execute the calculation.
                    energy = kineticEnergy(mass, velocity);

                    //The result label will display the object's kinetic energy.
                    resultLabel.Text = energy.ToString("n1");

                }
                else
                {
                    //If the data was input incorrectly a message will display for the velocity.
                    MessageBox.Show("Velocity is Invalid.");
                }
            }
            else
            {
                //If the data was input incorrectly a message will display for the mass.
                MessageBox.Show("Mass is Invalid.");
            }

            
            
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //This will clear the data in the mass, velocity textbox and also clear the result label.
            objectsMassTextBox.Text = "";
            objectVelocityTextBox.Text = "";
            resultLabel.Text = "";

            objectsMassTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //This closes the form.
            this.Close();
        }
    }
}
