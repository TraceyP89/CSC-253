﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProductionWorkerClass;
using TeamLeaderClass;

/**
* 10/27/2021
* CSC 253
* Tracey Pinckney
* This program will allow the user to enter in and display their Shift Number, Hourly Pay Rate, Monthly Bonus, 
* Required training hours, and the training hours that the team leader attended.
*/
namespace WinFormsUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //This button will display the Shift Number, Hourly Pay Rate, Monthly Bonus, Required training hours, and the training
        //that the team leader attended. Also, what is inputted will be stored in the constructor of the classes
        private void displayButton_Click(object sender, EventArgs e)
        {
            TeamLeader tmLeader = new TeamLeader(int.Parse(shitNumberTextBox.Text), 
                                        decimal.Parse(hourlyPayRateTextBox.Text), int.Parse(monthlyBonusTextBox.Text), 
                                        int.Parse(reqTrainHoursTextBox.Text), int.Parse(numTrainHoursTextBox.Text));

            outputLabel.Text = "Shift Number: " + tmLeader.ShiftNum + "\n" +
                               "Hourly Pay Rate: " + tmLeader.HourlyRate.ToString("c") + "\n" +
                               "Monthly Bonus: " + tmLeader.MonthlyBonus.ToString("c") + "\n" +
                               "Required Training Hours: " + tmLeader.TrainHours + "\n" +
                               "Training Team Leader Attended: " + tmLeader.TeamLeadHours;
        }

        //This button will clear the textboxes and labels
        private void clearButton_Click(object sender, EventArgs e)
        {
            shitNumberTextBox.Text = "";
            hourlyPayRateTextBox.Text = "";
            monthlyBonusTextBox.Text = "";
            reqTrainHoursTextBox.Text = "";
            numTrainHoursTextBox.Text = "";
            outputLabel.Text = "";
        }

        //This button will close the program
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
