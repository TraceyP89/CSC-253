﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductionWorkerClass
{
    public class ProductionWorker
    {
        //This constructor will hold the data inputted for the shift number and hourly rate.
        public ProductionWorker(int shiftNum, decimal hourlyRate)
        {
            ShiftNum = shiftNum;
            HourlyRate = hourlyRate;
        }
        //These properties will get and set the shift number and hourly rate
        public int ShiftNum { get; set; }
        public decimal HourlyRate { get; set; }
    }
}
