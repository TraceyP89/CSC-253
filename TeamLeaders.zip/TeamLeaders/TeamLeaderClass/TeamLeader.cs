﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductionWorkerClass;


namespace TeamLeaderClass
{
    public class TeamLeader: ProductionWorker
    {
        //This constructor will hold the data that is inputted for monthly bonus, training hours required and team leader 
        //training hours attended. The constructor will also inherit the shift number and hourly rate from the 
        //production worker class
        public TeamLeader(int shiftNum, decimal hourlyRate, decimal monthlyBonus, double trainHours, double teamLeadHours)
            : base(shiftNum, hourlyRate)
        {
            MonthlyBonus = monthlyBonus;
            TrainHours = trainHours;
            TeamLeadHours = teamLeadHours;
        }
        //These properties will get and set the monthly bonus, training hours and team leader training hours.
        public decimal MonthlyBonus { get; set; }
        public double TrainHours { get; set; }
        public double TeamLeadHours { get; set; }
    }
}
