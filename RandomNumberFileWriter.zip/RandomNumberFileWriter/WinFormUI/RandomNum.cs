﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomNumbersLibrary
{
    public class RandomNum
    {
        //backing fields
        private int _randomNubmers;

        //constructor
        public RandomNum(int randomNumbers)
        {
            _randomNubmers = randomNumbers;
        }

        //Properties will  access the backing fields
        //Will get and set value
        public int RandomNumbers
        {
            get { return _randomNubmers; }
            set { _randomNubmers = value; }
        }

   

    }
}
