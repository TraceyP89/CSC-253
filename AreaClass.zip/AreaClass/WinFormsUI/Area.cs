﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 09-02-2021
* CSC 253
* Tracey Pinckney
* The program will display area of a cylinder, circle, and rectangle using overloaded static methods.
*/
namespace WinFormsUI
{
    
    static class Area
    {
        
       //This method will calculate area of the circle when called.
        public static double DisplayArea(double radius)
        {
            
            return Math.PI * Math.Pow(radius, 2);

        }

        //This method will calculate area of the rectangle when called.
        public static double DisplayArea(int height, int width)
        {
            return height * width;
        }

        //This method will calculate area of the cylinder when called.
        public static double DisplayArea(double radius, int height)
        {
            return Math.PI * Math.Pow(radius, 2) * height;
        }

    }
}
