﻿
namespace WinFormsUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.areaCircleButton = new System.Windows.Forms.Button();
            this.areaRectangleButton = new System.Windows.Forms.Button();
            this.areaCylinderButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.circleAreaLabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.rectangleAreaLabel = new System.Windows.Forms.Label();
            this.cylinderAreaLabel = new System.Windows.Forms.Label();
            this.circleRadiusLabel = new System.Windows.Forms.Label();
            this.recLengthWidthLabel = new System.Windows.Forms.Label();
            this.cylRadiusLengthLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // areaCircleButton
            // 
            this.areaCircleButton.Location = new System.Drawing.Point(72, 200);
            this.areaCircleButton.Name = "areaCircleButton";
            this.areaCircleButton.Size = new System.Drawing.Size(88, 37);
            this.areaCircleButton.TabIndex = 0;
            this.areaCircleButton.Text = "Show Area of Circle";
            this.areaCircleButton.UseVisualStyleBackColor = true;
            this.areaCircleButton.Click += new System.EventHandler(this.areaCircleButton_Click);
            // 
            // areaRectangleButton
            // 
            this.areaRectangleButton.Location = new System.Drawing.Point(166, 200);
            this.areaRectangleButton.Name = "areaRectangleButton";
            this.areaRectangleButton.Size = new System.Drawing.Size(100, 37);
            this.areaRectangleButton.TabIndex = 1;
            this.areaRectangleButton.Text = "Show Area of Rectangle";
            this.areaRectangleButton.UseVisualStyleBackColor = true;
            this.areaRectangleButton.Click += new System.EventHandler(this.areaRectangleButton_Click);
            // 
            // areaCylinderButton
            // 
            this.areaCylinderButton.Location = new System.Drawing.Point(272, 200);
            this.areaCylinderButton.Name = "areaCylinderButton";
            this.areaCylinderButton.Size = new System.Drawing.Size(84, 37);
            this.areaCylinderButton.TabIndex = 2;
            this.areaCylinderButton.Text = "Show Area of Cylinder";
            this.areaCylinderButton.UseVisualStyleBackColor = true;
            this.areaCylinderButton.Click += new System.EventHandler(this.areaCylinderButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(108, 359);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(84, 42);
            this.clearButton.TabIndex = 3;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(226, 359);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(82, 42);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Enter the circle\'s radius:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Rectangle\'s length and width:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(61, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Cylinder\'s radius and length:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(118, 258);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Area of Circle:";
            // 
            // circleAreaLabel
            // 
            this.circleAreaLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.circleAreaLabel.Location = new System.Drawing.Point(226, 248);
            this.circleAreaLabel.Name = "circleAreaLabel";
            this.circleAreaLabel.Size = new System.Drawing.Size(100, 23);
            this.circleAreaLabel.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(95, 293);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "Area of Rectangle:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(105, 327);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "Area Of Cylinder:";
            // 
            // rectangleAreaLabel
            // 
            this.rectangleAreaLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rectangleAreaLabel.Location = new System.Drawing.Point(226, 283);
            this.rectangleAreaLabel.Name = "rectangleAreaLabel";
            this.rectangleAreaLabel.Size = new System.Drawing.Size(100, 23);
            this.rectangleAreaLabel.TabIndex = 19;
            // 
            // cylinderAreaLabel
            // 
            this.cylinderAreaLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cylinderAreaLabel.Location = new System.Drawing.Point(226, 317);
            this.cylinderAreaLabel.Name = "cylinderAreaLabel";
            this.cylinderAreaLabel.Size = new System.Drawing.Size(100, 23);
            this.cylinderAreaLabel.TabIndex = 20;
            // 
            // circleRadiusLabel
            // 
            this.circleRadiusLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.circleRadiusLabel.Location = new System.Drawing.Point(214, 63);
            this.circleRadiusLabel.Name = "circleRadiusLabel";
            this.circleRadiusLabel.Size = new System.Drawing.Size(100, 23);
            this.circleRadiusLabel.TabIndex = 21;
            // 
            // recLengthWidthLabel
            // 
            this.recLengthWidthLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.recLengthWidthLabel.Location = new System.Drawing.Point(214, 103);
            this.recLengthWidthLabel.Name = "recLengthWidthLabel";
            this.recLengthWidthLabel.Size = new System.Drawing.Size(100, 23);
            this.recLengthWidthLabel.TabIndex = 22;
            // 
            // cylRadiusLengthLabel
            // 
            this.cylRadiusLengthLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cylRadiusLengthLabel.Location = new System.Drawing.Point(214, 140);
            this.cylRadiusLengthLabel.Name = "cylRadiusLengthLabel";
            this.cylRadiusLengthLabel.Size = new System.Drawing.Size(100, 23);
            this.cylRadiusLengthLabel.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(393, 427);
            this.Controls.Add(this.cylRadiusLengthLabel);
            this.Controls.Add(this.recLengthWidthLabel);
            this.Controls.Add(this.circleRadiusLabel);
            this.Controls.Add(this.cylinderAreaLabel);
            this.Controls.Add(this.rectangleAreaLabel);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.circleAreaLabel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.areaCylinderButton);
            this.Controls.Add(this.areaRectangleButton);
            this.Controls.Add(this.areaCircleButton);
            this.Name = "Form1";
            this.Text = "Area Class";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button areaCircleButton;
        private System.Windows.Forms.Button areaRectangleButton;
        private System.Windows.Forms.Button areaCylinderButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label circleAreaLabel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label rectangleAreaLabel;
        private System.Windows.Forms.Label cylinderAreaLabel;
        private System.Windows.Forms.Label circleRadiusLabel;
        private System.Windows.Forms.Label recLengthWidthLabel;
        private System.Windows.Forms.Label cylRadiusLengthLabel;
    }
}

