﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 09-02-2021
* CSC 253
* Tracey Pinckney
* The program will display area of a cylinder, circle, and rectangle using overloaded static methods.
*/
namespace WinFormsUI
{
    public partial class Form1 : Form
    {
        

        public Form1()
        {

            InitializeComponent();
        }

        //Created varibles 
        int widthCircle, recWidthLength, cylRadiusLength;

        private void Form1_Load(object sender, EventArgs e)
        {
            


            //Converted the above variables to strings so that it will display in the labels.
            circleRadiusLabel.Text = widthCircle.ToString("5.0");
            recLengthWidthLabel.Text = recWidthLength.ToString("6 3");
            cylRadiusLengthLabel.Text = cylRadiusLength.ToString("10 5");
        }
        
        //The button will display the area of the circle
        private  void areaCircleButton_Click(object sender, EventArgs e)
        {
            
            //Calling the method and giving the method a value the matches the data type of the arguments that were
            //passed in the method. The value passed was a double.
            double radius = Area.DisplayArea(5.0);

            //Will display the area of the circle.
            circleAreaLabel.Text = radius.ToString("n2");                
            
        }

        private void areaRectangleButton_Click(object sender, EventArgs e)
        {
            //Calling the method and giving the method a value the matches the data type of the arguments that were
            //passed in the method. The values passed were integer and integer.
            double rectangle = Area.DisplayArea(6, 3);

            //Will display the area of the rectangle.
            rectangleAreaLabel.Text = rectangle.ToString("n2");
        }

        
        private void areaCylinderButton_Click(object sender, EventArgs e)
        {
            //Calling the method and giving the method with a value the matches the data type of the arguments that were
            //passed in the method. The values passed were a double and integer.
            double cylinder = Area.DisplayArea(10.0, 5);

            //Will display the area of the cylinder.
            cylinderAreaLabel.Text = cylinder.ToString("n2");

        }

        //This will clear the data on the form.
        private void clearButton_Click(object sender, EventArgs e)
        {
            circleRadiusLabel.Text = "";
            recLengthWidthLabel.Text = "";
            cylRadiusLengthLabel.Text = "";
            circleAreaLabel.Text = "";
            rectangleAreaLabel.Text = "";
            cylinderAreaLabel.Text = "";
        }

        //This closes the form
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
