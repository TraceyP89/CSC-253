﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsUI
{
    public static class Tuiton
    {
        //This method will iterate through the loop to display the next 5 eyars and the tuition for the next 5 years.
        public static List<string> InceaseTut(decimal tuition = 6000, decimal percentIncrease = 0.02m)
        {
            List<string> increase = new List<string>();
            for (int year = 2022; year <= 2027; year++)
            {
               increase.Add($"New tuition for {year} is { tuition = tuition + tuition * percentIncrease}");

            }
            return increase;

        }
    }
}
