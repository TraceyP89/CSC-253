﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/**
* 11-16-2021
* CSC 253
* Tracey Pinckney
* This program will display the tuition for the next 5 years.
*/
namespace WinFormsUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //This button will display the tuition for the next 5 years in the listbox
        private void displayButton_Click(object sender, EventArgs e)
        {
            tuitionIncreaseListBox.Items.Clear();

            List<string> increase = Tuiton.InceaseTut();

            //This foreach loop will iterate through the List<string>IncreaseTut method and display the data
            foreach(string message in increase)
            {
                tuitionIncreaseListBox.Items.Add(message);
            }
        }

       

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
