﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TuitionIncrease;

namespace TuitionIncrease.Tests
{
   public class LoopTests
    {
        public void Add_SimpleValuesShouldLoop()
        {
            //Arrange 
            double expected = 
        }
    }
}
