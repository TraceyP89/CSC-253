﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuitionIncreaseClass
{
    public static class TuitionIncrease
    {
        public static decimal InceaseTut(decimal tuition, decimal percentIncrease)
        {
            for (int year = 2022; year <= 2027; year++)
            {
                tuition = tuition + tuition * percentIncrease;
                return tuition;
            }
            return tuition;   
        }
    }
    }
}
