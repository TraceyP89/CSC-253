﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using WinFormsUI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ;



namespace WinFormsUI.Tests
{
    //This will test that the data contained in the list is suppose to be in the list.
    [TestClass()]
    public class Form1Tests
    {
        [TestMethod()]
        public void Increase_Tuition()
        {
            //Arrange
            decimal tuition = 7000;
            decimal percetIncrease = 0.02m;
            double expected = 6120;

            //act
            Tuiton.InceaseTut(tuition, percetIncrease)
            Assert.AreEqual;
        }

        [TestMethod()]
        public void InceaseTutTest()
        {
            Assert.Fail();
        }
    }
}