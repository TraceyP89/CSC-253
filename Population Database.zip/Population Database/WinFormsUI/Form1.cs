﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PopulationClassLibrary;

/**
* 10/10/2021
* CSC 253
* Tracey Pinckney
* This program will display data in data grid view. The data can be sorted in ascending and descending order.
* The data will be totaled and averaged when the Calculate button is clicked.
*/
namespace WinFormsUI
{
    public partial class Form1 : Form
    {
        //Object for class
        PopulationClass myPopulationClass = new PopulationClass(0, 0);
        public Form1()
        {
            InitializeComponent();
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._PopulationDB__1_DataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the '_PopulationDB__1_DataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this._PopulationDB__1_DataSet.City);

        }

        //This button will sort the data in ascending order by the population
        private void ascendButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.FillByPopulationAscend(this._PopulationDB__1_DataSet.City);
        }

        //This button will sort the data in descending order by the population
        private void descendButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.FillByPopulationDesc(this._PopulationDB__1_DataSet.City);
        }

        //This button will calculate the average and total population of the cities listed and display the average and total
        //Also, this button will display the highest and lowest population
        private void calculateButton_Click(object sender, EventArgs e)
        {
            int averagePopulation,
                totalPopulation,
                highestPopulation,
                lowestPopulation;

            averagePopulation = (int)this.cityTableAdapter.AveragePopulation();
            myPopulationClass.Average = averagePopulation;
            avgPopLabel.Text = myPopulationClass.Average.ToString("n");

            totalPopulation = (int)this.cityTableAdapter.TotalPopulation();
            myPopulationClass.Total = totalPopulation;
            totPopLabel.Text = myPopulationClass.Total.ToString("n");

            highestPopulation = (int)this.cityTableAdapter.HighestPopulation();
            highestPopLabel.Text = highestPopulation.ToString("n");

            lowestPopulation = (int)this.cityTableAdapter.LowestPopulation();
            lowestPopLabel.Text = lowestPopulation.ToString("n");
        }

        //this will close the program
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //This will clear the labels
        private void clearButton_Click(object sender, EventArgs e)
        {
            totPopLabel.Text = "";
            avgPopLabel.Text = "";
            highestPopLabel.Text = "";
            lowestPopLabel.Text = "";
        }
    }
}
