﻿namespace WinFormsUI
{


    partial class _PopulationDB__1_DataSet
    {
    }
}

namespace WinFormsUI._PopulationDB__1_DataSetTableAdapters {
    
    
    public partial class CityTableAdapter {
    }
}
