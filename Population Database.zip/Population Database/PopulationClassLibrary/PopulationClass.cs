﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PopulationClassLibrary
{
    public class PopulationClass
    {
        //backing fields to hold the data
        private int _average;
        private int _total;

        //Constructor will hold the values for the backing fields.
        public PopulationClass(int average, int total)
        {
            _average = average;
            _total = total;
        }

        //Properties that will get and set the values. 
        public int Average
        {
            get { return _average; }
            set { _average = value; }
        }

        public int Total
        {
            get { return _total; }
            set { _total = value; }
        }
    }
}
