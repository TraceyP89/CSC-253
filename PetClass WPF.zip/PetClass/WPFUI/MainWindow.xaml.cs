﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PetClassLibrary;

/**
* 11/21/2021
* CSC 253
* Tracey Pinckney
* This program will allow the user to input their pet's name, type, and age.
*/
namespace WPFUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //This object will store the data inputted by the user to the class properties and the constructors
                PetClass myPetClass = new PetClass(petNameTextBox.Text, petTypeTextBox.Text, int.Parse(petAgeTextBox.Text));

                if (!string.IsNullOrWhiteSpace(myPetClass.Name) && !petInfoListBox.Items.Contains(myPetClass.Name))
                {
                    petInfoListBox.Items.Add("Name: " + myPetClass.Name);
                    petNameTextBox.Clear();
                }
                else
                {
                    MessageBox.Show("Must enter a name!");
                }

                if (!string.IsNullOrWhiteSpace(myPetClass.Type) && !petInfoListBox.Items.Contains(myPetClass.Type))
                {
                    petInfoListBox.Items.Add("Type: " + myPetClass.Type);
                    petTypeTextBox.Clear();
                }
                else
                {
                    MessageBox.Show("Must enter the type of pet!");
                }

                if (!string.IsNullOrWhiteSpace(petAgeTextBox.Text) && !petInfoListBox.Items.Contains(myPetClass.Age))
                {
                    petInfoListBox.Items.Add("Age: " + myPetClass.Age);
                    petAgeTextBox.Clear();
                }
                else
                {
                    MessageBox.Show("Must enter the type of pet!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        //this will close the form
        private void exitButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        //this will clear the textboxes and listbox
        private void clearButton_Click(object sender, RoutedEventArgs e)
        {
            petInfoListBox.Items.Clear();
            petNameTextBox.Text = "";
            petTypeTextBox.Text = "";
            petAgeTextBox.Text = "";
        }
    }
}
