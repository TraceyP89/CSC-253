﻿using System;

namespace CounterLibrary
{
  
    public class Class1
    {
        CounterLibrary myCount = new CounterLibrary();
        class CounterLibrary
        {
            //This method will return the count of letters that was inputted in the textbox.

            public int CountingLetters { get; set; }
            
        }
    }
}
