﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 09-05-2021
* CSC 253
* Tracey Pinckney
* This program will count and display the number letter inputted in.
*/
namespace WinFormsUI
{
    public partial class Form1 : Form
    {
        //This object will pull the data from the class Counter and connects the data to form1.
        CounterLibrary myCount = new CounterLibrary();
        public Form1()
        {
            InitializeComponent();
        }

        
        private void letterCounterButton_Click(object sender, EventArgs e)
        {
            //This variable will get what is inputted in the textbox.
            string lettersEntered = lettersEnteredTextBox.Text;

            //This will display the number of letters that was inputted in the textbox
            //using the CountingLetters method that is in the class Counter.
            MessageBox.Show("Number of Letters: " + myCount.CountingLetters(lettersEntered));
           
        }

        //This closes the form.
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
