﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*09 - 05 - 2021
* CSC 253
* Tracey Pinckney
* This program will count and display the number letter inputted in.
*/
namespace WinFormsUI
{
    class CounterLibrary
    {
        //This method will return the count of letters that was inputted in the textbox.

        public int CountingLetters(string str)
        {
            string[] textLetters = str.Split();
            return textLetters.Length;
        }
    }
}
