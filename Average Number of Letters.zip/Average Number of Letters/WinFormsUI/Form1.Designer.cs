﻿
namespace WinFormsUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lettersEnteredTextBox = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.letterCounterButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(44, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter in Letters:";
            // 
            // lettersEnteredTextBox
            // 
            this.lettersEnteredTextBox.Location = new System.Drawing.Point(47, 81);
            this.lettersEnteredTextBox.Name = "lettersEnteredTextBox";
            this.lettersEnteredTextBox.Size = new System.Drawing.Size(271, 20);
            this.lettersEnteredTextBox.TabIndex = 1;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(128, 119);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 48);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // letterCounterButton
            // 
            this.letterCounterButton.Location = new System.Drawing.Point(47, 119);
            this.letterCounterButton.Name = "letterCounterButton";
            this.letterCounterButton.Size = new System.Drawing.Size(75, 48);
            this.letterCounterButton.TabIndex = 3;
            this.letterCounterButton.Text = "Letter Counter";
            this.letterCounterButton.UseVisualStyleBackColor = true;
            this.letterCounterButton.Click += new System.EventHandler(this.letterCounterButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(371, 209);
            this.Controls.Add(this.letterCounterButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.lettersEnteredTextBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox lettersEnteredTextBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button letterCounterButton;
    }
}

