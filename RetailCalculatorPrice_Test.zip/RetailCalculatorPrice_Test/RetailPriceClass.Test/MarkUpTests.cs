﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailPriceClass;
using Xunit;

namespace RetailPriceClass.Test
{
    //This class tests the CalculateMarkup to ensure that the calcuation is working. 
    public class MarkUpTests
    {
        [Fact]
        public void Add_SimpleValuesShouldCalculator()
        {
            //This is the expected result with 5.60 is inputted in the form for markup and is divided by 100
            // Arrange
            decimal expected = 0.056m;

            //This is the actual number inputted by the user to get the result 0.056
            // Act
            decimal actual = RetailPrice.CalculateMarkup(5.60m);

            //This will compare the expected and actual. If the test pass then the program is working correctly.
            // Assert
            Assert.Equal(expected, actual);
        }
    }

}
