﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RetailPriceClass;


/**
* 11/15/2021
* CSC 253
* Tracey Pinckney
* In this program the form will allow the user to input the wholesale value, and the markup percentage to receive the retail price. The MarkupTest will test the markup calculation.
*/
namespace WinFormsUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        //This button will display the retail price when the user enters in the wholesale value and markup percentage
        private void displayButton_Click(object sender, EventArgs e)
        {
            //This object will store the wholsale value and the markup percentage. It also calls the CalculateMarkup method
            RetailPrice myRetailPrice = new RetailPrice(0,0);


            myRetailPrice.Wholesale = decimal.Parse(wholeSaleTextBox.Text);
            myRetailPrice.Markup = RetailPrice.CalculateMarkup(decimal.Parse(markUpTextBox.Text));
            decimal retailPrice = myRetailPrice.Wholesale + myRetailPrice.Markup;

            //When the display button is clicked the retail price will be displayed in this label
            retailPriceLabel.Text = retailPrice.ToString("c");
        }

        //This closes the form
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //This button clears the data from the textboxes and label
        private void clearButton_Click(object sender, EventArgs e)
        {
            wholeSaleTextBox.Text = "";
            markUpTextBox.Text = "";
            retailPriceLabel.Text = "";
        }
    }
}
