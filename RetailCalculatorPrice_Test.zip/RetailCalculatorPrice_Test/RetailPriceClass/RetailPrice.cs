﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailPriceClass
{
    //This class will retrieve the wholesale data and the markup data that was entered by the user
    public class RetailPrice
    {

        public RetailPrice(decimal wholesale, decimal markup)
        {
            Wholesale = wholesale;
            Markup = markup;
        }
        public decimal Wholesale { get; set; }
        public decimal Markup { get; set; }

        //This method will divide 100 by what the user inputs for the markup percentage
        public static decimal CalculateMarkup(decimal markup)
        {
            return markup / 100;
        }
    }
}
