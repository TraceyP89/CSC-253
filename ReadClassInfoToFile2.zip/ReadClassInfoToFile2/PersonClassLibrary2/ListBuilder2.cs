﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 09/22/2021
* CSC 253
* Your Name
* This program will let the user input data. The data will write to an excel spreadsheet and display in the excel spreadsheet.
*/

namespace PersonClassLibrary2
{
    public class ListBuilder2
    { 
        //The data that the user inputs will be assign to this list
        public static List<PersonClass> people = new List<PersonClass>();
    }
}
