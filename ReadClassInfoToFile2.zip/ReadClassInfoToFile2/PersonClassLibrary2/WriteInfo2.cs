﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
/**
* 09/22/2021
* CSC 253
* Your Name
* This program will let the user input data. The data will write to an excel spreadsheet and display in the excel spreadsheet.
*/

namespace PersonClassLibrary2
{
    public static class WriteInfo2
    {
        public static string WriteFile()
        {
            //Variable
            StreamWriter outputFile;

            try
            {
                //Variable that creates "User Information" file
                outputFile = File.CreateText("UserInformation.csv");

                //foreach loop will loop through the list and save the data that the user inputted to the User Information spreadsheet
                foreach (PersonClass person in ListBuilder2.people)
                {
                    //get the data and writes it to the file 
                    outputFile.WriteLine($"{person.FirstName}, {person.LastName}, { person.MiddleName}, { person.Age}");
                }
                //Closes the file
                outputFile.Close();

                return "Saved";

            }
            catch (Exception ex)
            {
                //Variable to hold error message
                string message = ex.Message;
                //Message will display if there is an error
                return message;
            }
        }
    }
}
