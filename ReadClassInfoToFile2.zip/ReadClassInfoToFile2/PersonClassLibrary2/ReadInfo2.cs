﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
/**
* 09/22/2021
* CSC 253
* Your Name
* This program will let the user input data. The data will write to an excel spreadsheet and display in the excel spreadsheet.
*/

namespace PersonClassLibrary2
{
    public static class ReadInfo2
    {
        public static string ReadFile()
        {
            StreamReader inputFile;

            try
            {
                inputFile = File.OpenText("UserInformation.csv");

                //Will loop through the file but will stop once the loop reaches the end of the file
                while (!inputFile.EndOfStream)
                {
                    string[] tokens = inputFile.ReadLine().Split(',');
                    ListBuilder2.people.Add(new PersonClass(tokens[0], tokens[1], tokens[2], int.Parse(tokens[3])));
                }
                inputFile.Close();
                return " Loaded";

            }
            catch(Exception ex)
            {
                string message = ex.Message;
                return message;
            }
        }
    }
}
