﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PersonClassLibrary2;
/**
* 09/22/2021
* CSC 253
* Your Name
* This program will let the user input data. The data will write to an excel spreadsheet and display in the excel spreadsheet.
* The data will also display in the listbox when the Read User Informtion is clicked
*/

namespace WinFormsUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void writeUserInforButton_Click(object sender, EventArgs e)
        {
            WriteInfo2.WriteFile();
           
            //Variable to hold the user input
            string firstName = firstNameTextBox.Text;
            string middleName = middleNameTextBox.Text;
            string lastName = lastNameTextBox.Text;
            int age = int.Parse(ageTextBox.Text);

            //will assign the user's input to the ListBuilder2
            PersonClass person = new PersonClass(firstName, middleName, lastName, age);
            ListBuilder2.people.Add(person);

            //Clears the text box when the write user information button is clicked
            firstNameTextBox.Text = "";
            middleNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            ageTextBox.Text = "";

            //
            //Will let the user know that the data is saved
            MessageBox.Show("Saved");
        }

        private void readInfoButton_Click(object sender, EventArgs e)
        {
            ReadInfo2.ReadFile();

            //this loop will loop through the class and asssign the data the use input to the properties
            foreach(PersonClass person in ListBuilder2.people)
            {
                personListBox.Items.Clear();
                personListBox.Items.Add(person.FirstName);
                personListBox.Items.Add(person.MiddleName);
                personListBox.Items.Add(person.LastName);
                personListBox.Items.Add(person.Age);
            }
            
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the form
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clears the listbox 
            personListBox.Items.Clear();
        }
    }
}
