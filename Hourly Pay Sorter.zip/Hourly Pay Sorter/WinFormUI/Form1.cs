﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 10/7/2021
* CSC 253
* Tracey Pinckney
* This program is a database.
* This database holds data for the employee ID, name, position, and hourly pay rate and will display the data in DataGrid View. 
* Also, the program will ascend and descend by the hourly pay rate
*/
namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.employeeDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'employeeDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.employeeDataSet.Employee);

        }

        //This button will ascend the data by the hourly pay rate
        private void ascendingButton_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.FillByhourlyPayRateAsce(this.employeeDataSet.Employee);
        }

        //This button will descend the data by the hourly pay rate
        private void descendingButton_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.FillByhourlyPayRateDesc(this.employeeDataSet.Employee);
        }

        //this will close the database
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
