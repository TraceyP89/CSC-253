﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeClass;

namespace ProductionClass
{
    //This class will get and set the shift worked and hourly pay rate that the employee inputted
    public class ProductionWorker : Employee
    {
        //This constructor will hold the values for the parameters for Production Worker and for the inherited class
        public ProductionWorker(string name, int number, int shiftNum, decimal hourlyRate) : base(name, number)
        {
            ShiftNum = shiftNum;
            HourlyRate = hourlyRate;
        }
        //These are the propteries that will store the data for the shift number and the hourly pay rate
        public int ShiftNum { get; set; }
        public decimal HourlyRate { get; set; }

    }
}
