﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProductionClass;
using EmployeeClass;
/**
* 10/24/2021
* CSC 253
* Tracey Pinckney
* This program will display the get the employee's name, number, hourly pay rate and what shift they work and then their data
* will be displayed.
*/
namespace WinFormsUI
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        //This button will display the employee name, number, hourly pay rate, and what shift the employee works. 
        //When the data is entered it will be store in the ProductionWorker and Employee Class
        private void displayButton_Click_1(object sender, EventArgs e)
        {
            //This button  will display the data entered in by the user. 
            try
            {
                int shift = 0;
                if(dayRadioButton.Checked == true)
                {
                    shift = 1;
                }
                else
                {
                    shift = 2;
                }
                ProductionWorker pdWorker = new ProductionWorker(EmployeeNameTextBox.Text, int.Parse(EmployeeNumTextBox.Text), shift, decimal.Parse(hourlyPayRateTextBox.Text));
     
                outputLabel.Text = "Employe Name: " + pdWorker.Name + "\n" +
                                "Employee Number: " + pdWorker.Number + "\n" +
                                "Shift Number: " + pdWorker.ShiftNum + "\n" +
                                "Hourly pay rate: " + pdWorker.HourlyRate.ToString("c");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        

        //This button will clear the form
        private void clearButton_Click(object sender, EventArgs e)
        {
            EmployeeNameTextBox.Text = "";
            EmployeeNumTextBox.Text = "";
            hourlyPayRateTextBox.Text = "";
            outputLabel.Text = "";
        }

        //This button will close the form
        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
