﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClass
{
    //This class will get and set the data entered by the employee
    public class Employee
    {
        //This constructor will hold the values for the parameter and the ProductionWorker class will inherit from it. 
        public Employee(string name, int number)
        {
            Name = name;
            Number = number;
        }
        //These are the properties that will hold the employees name and the employee number
        public string Name { get; set; }
        public int Number { get; set; }
    }
}
