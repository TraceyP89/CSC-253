﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 10/7/2021
* CSC 253
* Tracey Pinckney
* This program is a database.
* This database holds data for the employee ID, name, position, and hourly pay rate and will search by name the data in DataGrid View. 
*/
namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.employeeDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'employeeDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.employeeDataSet.Employee);

        }

        //This button will search by name. When user type in a name from the list will only display the name
        private void searchButton_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.FillBySearchName(this.employeeDataSet.Employee, searchTextBox.Text);
        }

        //This button will display all of the names
        private void showAllButton_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.Fill(this.employeeDataSet.Employee);
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
