﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 08/22/2021
* CSC 253
* Tracey Pinckney
* This program will convert the temperature from Celsius to Fahrenheit starting from 0 -20.
*/
namespace WinForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void temperatureResultsButton_Click(object sender, EventArgs e)
        {
            //Declare variables for celsius and farenheit.
            double celsiusTemp;
            double fahrenheitTemp;

            //Displays the headers for Celsius to Fahrenheit
            temperatureListBox.Items.Add("C \t F");

            //When this loop executes, the loop will initiate from 0 and will stop at 20.
            for (celsiusTemp = 0; celsiusTemp <= 20; celsiusTemp++)
            {
                //Calcualation will convert celsius to fahrenheit
                fahrenheitTemp = (9.0 / 5.0) * celsiusTemp + 32;

                //The list box will display the conversion of Celsius to Fahrenheit
                //starting from 0 to 20.
                temperatureListBox.Items.Add(celsiusTemp + "\t" + fahrenheitTemp);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //This clears the list box.
            temperatureListBox.Items.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //This closes the form.
            this.Close();
        }

       
    }
}
