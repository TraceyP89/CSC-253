﻿using System;

namespace WordCounterLibrary
{
    public class Class1
    {
        Counter myCount = new Counter();

        class Counter 
        {
            //This is the property. This property will get the data and set the data
            public string wordCount { get; set; }
        }
        
  
    }
}
