﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 09/05/2021
* CSC 253
* Tracey Pincnkey
* This program will tell how many words were inputted in the form.
*/
namespace WinFormsUI
{
    public partial class Form1 : Form
    {
        //This object will pull the data from the class Counter and connects the data to form1.
        Counter myCount = new Counter();
        public Form1()
        {
            InitializeComponent();
        }


        private void wordCounterButton_Click(object sender, EventArgs e)
        {
            //This variable will get what is inputted in the textbox.
            //The trim method will remove all spaces that was entered in the textbox.
            string wordsEntered = wordsEnteredTextBox.Text.Trim();

            //This will display the number of words that was inputted in the textbox
            //using the CountingWords method that is on the class Counter.
            MessageBox.Show("Number of Words: " + myCount.CountingWords(wordsEntered));

        }
        //This button closes out the form.
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
