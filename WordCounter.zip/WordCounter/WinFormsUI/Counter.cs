﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsUI
{
    class Counter
    {
        //This is the backing fields for the class
        
        //This method will divide the string from delimiters or the below spaces (' '). 
        //The return will count the number of words.
        public int CountingWords(string str)
        {
            string[] textWords = str.Split(' ');
            return textWords.Length;
        }
        



    }
}
