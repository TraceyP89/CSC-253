﻿
namespace WinFormsUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wordCounterButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.wordsEnteredTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // wordCounterButton
            // 
            this.wordCounterButton.Location = new System.Drawing.Point(90, 126);
            this.wordCounterButton.Name = "wordCounterButton";
            this.wordCounterButton.Size = new System.Drawing.Size(75, 39);
            this.wordCounterButton.TabIndex = 1;
            this.wordCounterButton.Text = "Word Counter";
            this.wordCounterButton.UseVisualStyleBackColor = true;
            this.wordCounterButton.Click += new System.EventHandler(this.wordCounterButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(171, 126);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 39);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // wordsEnteredTextBox
            // 
            this.wordsEnteredTextBox.Location = new System.Drawing.Point(36, 88);
            this.wordsEnteredTextBox.Name = "wordsEnteredTextBox";
            this.wordsEnteredTextBox.Size = new System.Drawing.Size(282, 20);
            this.wordsEnteredTextBox.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(33, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 23);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter in words:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(330, 229);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.wordsEnteredTextBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.wordCounterButton);
            this.Name = "Form1";
            this.Text = "Word Counter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button wordCounterButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox wordsEnteredTextBox;
        private System.Windows.Forms.Label label1;
    }
}

