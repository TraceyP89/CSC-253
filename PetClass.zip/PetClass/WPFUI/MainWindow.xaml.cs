﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PetClassLibrary;

/**
* 11/21/2021
* CSC 253
* Tracey Pinckney
* This program will allow the user to input their pet's name, type, and age.
*/
namespace WPFUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //This object will store the data inputted by the user to the class properties and the constructors
                PetClass myPetClass = new PetClass(petNameTextBox.Text, petTypeTextBox.Text, petAgeTextBox.Text);

                //this if-elseif-else statement says that if the textboxes(whitespaces) are blank, a message will appear letting
                //the user know the boxes need to be fill.
                if (string.IsNullOrWhiteSpace(myPetClass.Name) || string.IsNullOrWhiteSpace(myPetClass.Type) || string.IsNullOrWhiteSpace(myPetClass.Age))
                {
                    MessageBox.Show("Must enter required data!");
                }
                else if (petInfoListBox.Items.Contains(myPetClass.Name))
                {
                    MessageBox.Show($"The name {myPetClass.Name} already exists in the list!");
                }
                else
                {
                    petInfoListBox.Items.Add($"Name: {myPetClass.Name} \nType: {myPetClass.Type} \nAge: {myPetClass.Age}");
                    petNameTextBox.Clear();
                    petTypeTextBox.Clear();
                    petAgeTextBox.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //this will close the form
        private void exitButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        //this will clear the textboxes and listbox
        private void clearButton_Click(object sender, RoutedEventArgs e)
        {
            petInfoListBox.Items.Clear();
            petNameTextBox.Text = "";
            petTypeTextBox.Text = "";
            petAgeTextBox.Text = "";
        }
    }
}
