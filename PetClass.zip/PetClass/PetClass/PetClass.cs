﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetClassLibrary
{
    //backing fields that will store the data inputted by the user
    public class PetClass
    {
        private string _name;
        private string _type;
        private string _age;

        //parameterized constructor
        public PetClass(string name, string type, string age)
        {
            _name = name;
            _type = type;
            _age = age;
        }
        //properties that will receive the user data from the textboxes
        public string Name


        {
            get { return _name; }
            set { _name = value; }
        }
        public string Type
        {
            get { return _type; }
            set { _type = value; }
        }
        public string Age
        {
            get { return _age; }
            set { _age = value; }
        }
    }
}
