﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeClass;
namespace ShiftSupervisorClass
{
    public class ShiftSupervisor: Employee
    {
        //this constructor will hold the users salary, bonus and the parameters of the inherited class
        public ShiftSupervisor(string name, int number, decimal annualSalary, decimal annualBonus): base(name, number)
        {
            AnnualSalary = annualSalary;
            AnnualBonus = annualBonus;
        }

        //These properties will get and set the hourly rate, annual salary, and annual bonus
        public decimal AnnualSalary { get; set; }
        public decimal AnnualBonus { get; set; }

        
    }
}
