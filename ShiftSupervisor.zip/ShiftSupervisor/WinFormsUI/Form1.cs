﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeClass;
using ShiftSupervisorClass;
/**
* 10/24/2021
* CSC 253
* Tracey Pinckney
* This program will receive the supervisor's data and display it
*/
namespace WinFormsUI
{
    public partial class Form1 : Form
    {
        ShiftSupervisor sSupervisor = new ShiftSupervisor();
        public Form1()
        {
            InitializeComponent();
        }

        //This button will display the supervisors name, supervisor number, hourly rate, salary, and bonus
        private void displayButton_Click(object sender, EventArgs e)
        {
            try
            {
                sSupervisor.Name = SupervisorNameTextBox.Text;
                sSupervisor.Number = int.Parse(SupervisorNumTextBox.Text);
                sSupervisor.HourlyRate = decimal.Parse(hourlyPayRateTextBox.Text);
                sSupervisor.AnnualSalary = decimal.Parse(hourlyPayRateTextBox.Text) * 80 * 12;
                sSupervisor.AnnualBonus = sSupervisor.AnnualSalary * decimal.Parse(annualBonusTextBox.Text);
                outputLabel.Text = "Employe Name: " + sSupervisor.Name + "\n" +
                                "Employee Number: " + sSupervisor.Number + "\n" +
                                "Hourly pay rate: " + sSupervisor.HourlyRate.ToString("c") + "\n" +
                                "Annual Salary: " + sSupervisor.AnnualSalary.ToString("c") + "\n" +
                                "Annual Bonus: " + sSupervisor.AnnualBonus.ToString("c") + "\n";
                               

            }
            //This will display an error message if the user inputs something incorrectly
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //This will closes the form
        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //This clears the form
        private void clearButton_Click(object sender, EventArgs e)
        {
            SupervisorNameTextBox.Text = "";
            SupervisorNumTextBox.Text = "";
            hourlyPayRateTextBox.Text = "";
            annualBonusTextBox.Text = "";
            outputLabel.Text = "";
        }
    }
}
