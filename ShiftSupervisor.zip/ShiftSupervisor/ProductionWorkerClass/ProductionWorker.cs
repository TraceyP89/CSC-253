﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeClass;

namespace ProductionWorkerClass
{
    public class ProductionWorker: Employee
    {
        public ProductionWorker(string name, int number, int shiftNum, decimal hourlyRate) : base(name, number)
        {
            ShiftNum = shiftNum;
            HourlyRate = hourlyRate;
        }
        public int ShiftNum { get; set; }
        public decimal HourlyRate { get; set; }     
    }
}
