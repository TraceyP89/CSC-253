﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeClass;
using ShiftSupervisorClass;
/**
* 10/26/2021
* CSC 253
* Tracey Pinckney
* This program will receive the supervisor's data and display it
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //This button will display the user name, number, salary, bonus and total salary
        private void displayButton_Click(object sender, EventArgs e)
        {
            ShiftSupervisor sSupervisor = new ShiftSupervisor(EmployeeNameTextBox.Text, int.Parse(EmployeeNumTextBox.Text),
                        decimal.Parse(shiftTextBox.Text), decimal.Parse(annualBonusTextBox.Text));

            sSupervisor.AnnualSalary = decimal.Parse(hourlyPayRateTextBox.Text) * 80 * 12;
            sSupervisor.AnnualBonus = sSupervisor.AnnualSalary * decimal.Parse(annualBonusTextBox.Text);
            decimal totalSalary = sSupervisor.AnnualSalary + sSupervisor.AnnualBonus;

            outputLabel.Text = "Employee Name: " + sSupervisor.Name + "\n" +
                               "Employee Number: " + sSupervisor.Number + "\n" +
                               "Annual Salary: " + sSupervisor.AnnualSalary.ToString("c") + "\n" +
                               "Annual Bonus: " + sSupervisor.AnnualBonus.ToString("c") + "\n" +
                               "Total Annual Salary: " + totalSalary.ToString("c");
        }
        
        //this button clears the textboxes and labels
        private void clearButton_Click(object sender, EventArgs e)
        {
            EmployeeNameTextBox.Text = "";
            EmployeeNumTextBox.Text = "";
            hourlyPayRateTextBox.Text = "";
            annualBonusTextBox.Text = "";
            outputLabel.Text = "";
        }

        //this button closes the form
        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
