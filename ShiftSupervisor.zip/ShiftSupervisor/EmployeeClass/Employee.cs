﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClass
{
    public class Employee
    {
        //This constructor will hold the employees name and number
        public Employee(string name, int number)
        {
            Name = name;
            Number = number;
        }
        //these properties will get and set the name and number of the user
        public string Name { get; set; }
        public int Number { get; set; }
    }
}
