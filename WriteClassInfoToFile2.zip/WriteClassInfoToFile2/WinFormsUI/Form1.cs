﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PersonClassLibrary2;
/**
*10/05/2021
* CSC 253
* Your Name
* This program will let the user input data. The data will write to an excel spreadsheet and display in the excel spreadsheet.
*/

namespace WinFormsUI
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
        }

       
        private void writeUserInforButton_Click(object sender, EventArgs e)
        {
            //The method will be call and from the textboxes will be added to the list.
            GetName.BuildPerson(firstNameTextBox.Text, lastNameTextBox.Text, middleNameTextBox.Text, int.Parse(ageTextBox.Text));


            //Clears the text box when the write user information button is clicked
            firstNameTextBox.Text = "";
            middleNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            ageTextBox.Text = "";

            //Will write the data from the list to the file
            WriteInfo2.WriteFile();
            //Will let the user know that the data is saved
            MessageBox.Show("Saved");
        }
        
        

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the form
            this.Close();
        }
    }
}
