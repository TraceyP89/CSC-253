﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 09/22/2021
* CSC 253
* Your Name
* This program will let the user input data. The data will write to an excel spreadsheet and display in the excel spreadsheet.
*/

namespace PersonClassLibrary2
{
    public class PersonClass
    {
        //backing fields
        private string _firstName;
        private string _lastName;
        private string _middleName;
        private int _age;


        //Constructor that holds the data 
     
        public PersonClass(string firstName, string lastName, string middleName, int age)
        {

            _firstName = firstName;
            _lastName = lastName;
            _middleName = middleName;
            _age = age;

        }
        //Properties that the user's input will be assigned to.
        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
            
           
        }
        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
            
        }
        
        public string MiddleName
        {
            get { return _middleName; }
            set { _middleName = value; }
           
            
            
        }
        public int Age
        {
            get { return _age; }
            set { _age = value; }

        }



    }
}