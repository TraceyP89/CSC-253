﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonClassLibrary2
{
   public static class GetName
    {
        public static void BuildPerson (string firstName, string lastName, string middleName, int age)
        {
            //The data that is held by the properties of the PersonClass2 will be added to the list
            ListBuilder2.people.Add(new PersonClass(firstName, lastName, middleName, age));
        }
    }
}
